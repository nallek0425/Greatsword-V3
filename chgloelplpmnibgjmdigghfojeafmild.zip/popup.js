chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.create({ 
		url: "http://www.gameflarex.com/games/play/lolbeans-io"
 	});
});
